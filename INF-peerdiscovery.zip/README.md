# INF 557 Project  
  
In order to launch the server, several actions must be taken :  
-  Create a folder named sharedFolder in which another folder named my_folder should be created.   
-  In my_folder, place the text to share with your peers  
-  Launch the Main.java file  
  
On localhost:4243, more information is available:
-  The state of communication with other peers
-  The state of the database  
-  The list of the downloaded files
-  The state of the other peers

Dying state was not implemented.

## Authors: 
Grégoire Roussel
Maxime Voiturez
Amaury Camus